import React from "react";

const Home = () => {
  return (
    <div className="background">
      <h2 className="firstheading">
        THE FASTEST
        <br /> EMBROIDERY CONVERSIONS <br /> ON THE PLANET
      </h2>
      <p className="secondheading mt-3"> - HOW WE DO IT</p>
    </div>
  );
};

export default Home;
