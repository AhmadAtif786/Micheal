import React from "react";
import { Col, Container, Row } from "react-bootstrap";
import parrot from "./images/parrot.jpg";
const Page4 = () => {
  return (
    <div>
      <Container>
        <h2 className="pg1heading mt-5" style={{ textAlign: "center" }}>
          WORKING TOGETHER TO PRODUCE THE BEST POSSIBLE RESULTS
          <br />
          <span style={{ fontSize: "26px" }}>
            {" "}
            OUR TOP 7 TIPS TO PRODUCE YOUR BEST EMBROIDERY FILE CONVERSIONS
          </span>
        </h2>
        <Row
          className="mt-5 mb-5"
          style={{ backgroundColor: "#f6fbfc", padding: "20px" }}
        >
          <Col md={4}></Col>
          <Col md={4}>
            <img src={parrot} style={{ width: "100%" }} />
          </Col>
          <Col md={4}>
            <img src={parrot} style={{ width: "100%" }} />
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Page4;
